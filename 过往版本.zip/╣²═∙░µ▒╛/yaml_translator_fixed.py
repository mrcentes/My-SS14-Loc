import os
import requests
import json
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time
from ruamel.yaml import YAML

#
# 这是第 5 版，也是最终的正确修复版本
#
def safe_constructor(self, suffix, node):
    """
    自定义构造器，用于处理所有以 '!type:' 开头的标签。
    'self' 是 RoundTripConstructor 实例。
    'self.loader' 是 RoundTripLoader 实例, 它继承了 YAML() 实例的属性。
    """
    
    if node.id == 'scalar':
        # 如果是标量标签 (如: !type:SomeTag value)，我们返回空字典
        return {}
    
    try:
        if node.id == 'mapping':
            # 'self.loader' (RoundTripLoader) 可以直接访问
            # 其父 'YAML' 实例的 'map_type'
            return self.construct_mapping(node, maptyp=self.loader.map_type)
            
        if node.id == 'sequence':
            # 'self.loader' (RoundTripLoader) 可以直接访问
            # 其父 'YAML' 实例的 'seq_type'
            return self.construct_sequence(node, seqtyp=self.loader.seq_type)
            
    except AttributeError as e:
        # 捕获一个我们没预料到的 'no attribute' 错误
        print(f"    [Constructor Error] 内部属性访问失败: {e}")
        # 回退到构造一个普通字典，这会丢失注释
        if node.id == 'mapping':
            return self.construct_mapping(node)
        if node.id == 'sequence':
            return self.construct_sequence(node)
    
    # 默认回退 (比如其他未处理的标量)
    # 理论上我们应该返回 self.construct_scalar(node)，但空字典更安全
    return {}


class DeepSeekTranslator:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.deepseek.com/v1/chat/completions"
        self.lock = threading.Lock()
        
    def translate(self, text, context_info=None):
        """使用DeepSeek API翻译文本"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        base_prompt = """请将以下英文翻译为中文,如果已经为中文则不翻译,只返回翻译结果,不要包含其他内容."""

        if context_info:
            context_parts = []
            if context_info.get('name'):
                context_parts.append(f"对象名称: {context_info['name']}")
            if context_info.get('description'):
                context_parts.append(f"对象描述: {context_info['description']}")
            if context_info.get('parent'):
                context_parts.append(f"父对象: {context_info['parent']}")
            if context_info.get('id'):
                context_parts.append(f"对象ID: {context_info['id']}")

            if context_parts:
                context_str = "\n".join(context_parts)
                prompt = f"""{base_prompt}

上下文信息（仅供翻译参考）：
{context_str}

待翻译文本：{text}"""
            else:
                prompt = f"{base_prompt}\n\n待翻译文本：{text}"
        else:
            prompt = f"{base_prompt}\n\n待翻译文本：{text}"

        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }

        try:
            with self.lock:
                time.sleep(0.1) 

            response = requests.post(self.base_url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            result = response.json()

            translated_text = result['choices'][0]['message']['content'].strip()
            
            if translated_text.startswith("```") and translated_text.endswith("```"):
                translated_text = translated_text[3:-3].strip()

            if translated_text != text:
                print(f"    翻译: '{text}' -> '{translated_text}'")
            return translated_text

        except Exception as e:
            print(f"    翻译失败 '{text}': {e}")
            return text


class YamlTranslator:
    def __init__(self, api_key, max_threads=4):
        self.translator = DeepSeekTranslator(api_key)
        self.max_threads = max_threads
        self.processed_files = 0
        self.total_files = 0
        self.lock = threading.Lock()
        
    def find_yaml_files(self, folder_path):
        """递归查找所有yaml文件"""
        yaml_files = []
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith(('.yml', '.yaml')):
                    yaml_files.append(os.path.join(root, file))
        return yaml_files

    def contains_chinese(self, text):
        """检查文本是否包含中文字符"""
        if not text or not isinstance(text, str):
            return False
        return any('\u4e00' <= char <= '\u9fff' for char in text)

    def _traverse_and_translate(self, node):
        """
        递归遍历YAML数据结构 (字典或列表) 并翻译。
        """
        if isinstance(node, dict):
            context_info = {}
            for key in ['name', 'description', 'id', 'parent']:
                if key in node and isinstance(node[key], str):
                    context_info[key] = node[key]
            
            for key_to_translate in ['name', 'description']:
                if key_to_translate in node and isinstance(node[key_to_translate], str):
                    value = node[key_to_translate]
                    
                    if value and not self.contains_chinese(value):
                        current_context = context_info.copy()
                        if key_to_translate in current_context:
                            del current_context[key_to_translate]
                            
                        translated_value = self.translator.translate(value, current_context)
                        node[key_to_translate] = translated_value

            for key, value in node.items():
                if isinstance(value, (dict, list)):
                    self._traverse_and_translate(value)
                    
        elif isinstance(node, list):
            for item in node:
                self._traverse_and_translate(item)

    def process_yaml_file(self, file_path):
        """
        使用 ruamel.yaml 加载、处理和保存文件，以保留格式和注释。
        """
        print(f"处理文件: {os.path.relpath(file_path)}")
        
        yaml_parser = YAML()
        yaml_parser.preserve_quotes = True
        yaml_parser.width = 4096
        
        # 注册我们自定义的构造器来处理 !type: 标签
        yaml_parser.Constructor.add_multi_constructor(u'!type:', safe_constructor)

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml_parser.load(f)

            self._traverse_and_translate(data)

            with open(file_path, 'w', encoding='utf-8') as f:
                yaml_parser.dump(data, f)

            print(f"  ✓ 已使用YAML解析器处理并更新文件")
        
        except Exception as e:
            print(f"  ✗ 处理文件失败: {e}")
            # 打印更详细的堆栈跟踪，以便调试
            import traceback
            traceback.print_exc()
    
    def translate_folder(self, folder_path):
        """翻译指定文件夹下的所有YAML文件"""
        if not os.path.exists(folder_path):
            print(f"错误：文件夹 '{folder_path}' 不存在")
            return
        
        print(f"开始扫描文件夹: {folder_path}")
        yaml_files = self.find_yaml_files(folder_path)
        
        if not yaml_files:
            print("未找到任何YAML文件")
            return
        
        self.total_files = len(yaml_files)
        print(f"找到 {self.total_files} 个YAML文件")
        print(f"使用 {self.max_threads} 个线程进行翻译")
        print("=" * 60)
        
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = [executor.submit(self.process_yaml_file, file_path) 
                      for file_path in yaml_files]
            
            for future in futures:
                future.result()
        
        print("=" * 60)
        print(f"翻译完成！共处理 {self.total_files} 个文件")


def main():
    print("YAML文件智能翻译器 (使用 ruamel.yaml 解析)")
    print("=" * 60)
    
    api_key = input("请输入DeepSeek API密钥: ").strip()
    if not api_key:
        print("错误：API密钥不能为空")
        return
    
    folder_path = input("请输入要处理的文件夹路径: ").strip()
    if not folder_path:
        print("错误：文件夹路径不能为空")
        return
    
    MAX_THREADS = 10 
    
    try:
        translator = YamlTranslator(api_key, MAX_THREADS)
        translator.translate_folder(folder_path)
        
    except KeyboardInterrupt:
        print("\n用户中断操作")
    except Exception as e:
        print(f"程序执行出错: {e}")
    
    input("\n按回车键退出...")


if __name__ == "__main__":
    main()