import os
import yaml
import requests
import json
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time
from ruamel.yaml import YAML

# 自定义构造器，将标量标签转换为空 dict
def safe_constructor(loader, node):
    # 如果 node 是 scalar（标量），返回空 mapping
    if node.id == 'scalar':
        return {}
    return loader.construct_mapping(node)

# 注册自定义构造器，处理 !type:* 标签
yaml = YAML()
yaml.Constructor.add_constructor(u'!type:ExplodeBehavior', safe_constructor)

class DeepSeekTranslator:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.deepseek.com/v1/chat/completions"
        self.lock = threading.Lock()
        
    def translate(self, text, context_info=None):
        """使用DeepSeek API翻译文本"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        # 硬编码的翻译prompt
        base_prompt = """请将以下英文翻译为中文,如果已经为中文则不翻译,只返回翻译结果,不要包含其他内容."""

        # 构建完整的prompt，包含上下文信息
        if context_info:
            context_parts = []
            if context_info.get('name'):
                context_parts.append(f"对象名称: {context_info['name']}")
            if context_info.get('description'):
                context_parts.append(f"对象描述: {context_info['description']}")
            if context_info.get('parent'):
                context_parts.append(f"父对象: {context_info['parent']}")
            if context_info.get('id'):
                context_parts.append(f"对象ID: {context_info['id']}")

            if context_parts:
                context_str = "\n".join(context_parts)
                prompt = f"""{base_prompt}

上下文信息（仅供翻译参考）：
{context_str}

待翻译文本：{text}"""
            else:
                prompt = f"{base_prompt}\n\n待翻译文本：{text}"
        else:
            prompt = f"{base_prompt}\n\n待翻译文本：{text}"

        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }

        try:
            with self.lock:
                time.sleep(0.1)  # 简单的速率限制

            response = requests.post(self.base_url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            result = response.json()

            translated_text = result['choices'][0]['message']['content'].strip()
            if translated_text != text:  # 仅在翻译结果不同于原文时打印
                print(f"    翻译: '{text}' -> '{translated_text}'")
            return translated_text

        except Exception as e:
            print(f"    翻译失败 '{text}': {e}")
            return text  # 翻译失败时返回原文


class YamlTranslator:
    def __init__(self, api_key, max_threads=4):
        self.translator = DeepSeekTranslator(api_key)
        self.max_threads = max_threads
        self.processed_files = 0
        self.total_files = 0
        self.lock = threading.Lock()
        
    def find_yaml_files(self, folder_path):
        """递归查找所有yaml文件"""
        yaml_files = []
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith(('.yml', '.yaml')):
                    yaml_files.append(os.path.join(root, file))
        return yaml_files
    def process_yaml_file(self, file_path):
        """逐行处理文件，翻译 name 和 description 字段"""
        print(f"处理文件: {os.path.relpath(file_path)}")

        def contains_chinese(text):
            """检查文本是否包含中文字符"""
            return any('\u4e00' <= char <= '\u9fff' for char in text)

        def find_context_value(lines, current_index, field_name, search_direction, search_range=3):
            """在指定方向和范围内查找指定字段的值"""
            if search_direction == "down":
                start = current_index + 1
                end = min(len(lines), current_index + 1 + search_range)
                search_lines = lines[start:end]
            else:  # search_direction == "up"
                start = max(0, current_index - search_range)
                end = current_index
                search_lines = lines[start:end]
            
            for line in search_lines:
                stripped = line.lstrip()
                if stripped.startswith(f"{field_name}:"):
                    _, value = stripped.split(":", 1)
                    return value.strip()
            return None

        try:
            # 逐行读取文件
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            translated_lines = []
            for i, line in enumerate(lines):
                stripped_line = line.lstrip()
                leading_spaces = len(line) - len(stripped_line)

                if stripped_line.startswith("name:") or stripped_line.startswith("description:"):
                    key, value = stripped_line.split(":", 1)
                    value = value.strip()
                    
                    if contains_chinese(value):
                        translated_lines.append(line)
                        continue
                    
                    # 构建上下文信息
                    context_info = {}
                    
                    if key == "name":
                        # 翻译name时，向下查找description
                        description_value = find_context_value(lines, i, "description", "down")
                        if description_value:
                            context_info['description'] = description_value
                    elif key == "description":
                        # 翻译description时，向上查找name
                        name_value = find_context_value(lines, i, "name", "up")
                        if name_value:
                            context_info['name'] = name_value
                    
                    # 传递上下文信息进行翻译
                    translated_value = self.translator.translate(value, context_info if context_info else None)
                    translated_line = f"{' ' * leading_spaces}{key}: {translated_value} \n"
                    translated_lines.append(translated_line)
                else:
                    translated_lines.append(line)

            # 写回文件
            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(translated_lines)

            print("  ✓ 已逐行处理并更新文件")
        except Exception as e:
            print(f"  ✗ 处理文件失败: {e}")
    
    def translate_folder(self, folder_path):
        """翻译指定文件夹下的所有YAML文件"""
        if not os.path.exists(folder_path):
            print(f"错误：文件夹 '{folder_path}' 不存在")
            return
        
        print(f"开始扫描文件夹: {folder_path}")
        yaml_files = self.find_yaml_files(folder_path)
        
        if not yaml_files:
            print("未找到任何YAML文件")
            return
        
        self.total_files = len(yaml_files)
        print(f"找到 {self.total_files} 个YAML文件")
        print(f"使用 {self.max_threads} 个线程进行翻译")
        print("=" * 60)
        
        # 使用多线程处理文件
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = [executor.submit(self.process_yaml_file, file_path) 
                      for file_path in yaml_files]
            
            # 等待所有任务完成
            for future in futures:
                future.result()
        
        print("=" * 60)
        print(f"翻译完成！共处理 {self.total_files} 个文件")


def main():
    print("YAML文件智能翻译器 (支持!type:标签)")
    print("=" * 60)
    
    # 获取用户输入
    api_key = input("请输入DeepSeek API密钥: ").strip()
    if not api_key:
        print("错误：API密钥不能为空")
        return
    
    folder_path = input("请输入要处理的文件夹路径: ").strip()
    if not folder_path:
        print("错误：文件夹路径不能为空")
        return
    
    # 硬编码线程数
    MAX_THREADS = 120
    
    try:
        # 创建翻译器并开始翻译
        translator = YamlTranslator(api_key, MAX_THREADS)
        translator.translate_folder(folder_path)
        
    except KeyboardInterrupt:
        print("\n用户中断操作")
    except Exception as e:
        print(f"程序执行出错: {e}")
    
    input("\n按回车键退出...")


if __name__ == "__main__":
    main()
